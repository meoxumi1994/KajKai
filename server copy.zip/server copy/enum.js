const SocialType = {
  	GOOGLE: 'Google',
  	FACEBOOK: 'Facebook',
};

const LoginType = {
	PHONE: 'phone',
	GOOGLE: 'google',
	FACEBOOK: 'Facebook'
}

const Language = {
	VIETNAM: 'VIETNAMESE',
	ENGLISH: 'ENGLISH'
}

const Sex = {
	MALE: 'MALE',
	FEMALE: 'FEMALE'
}

module.exports = {
	SocialType,
	LoginType,
	Language,
	Sex
}