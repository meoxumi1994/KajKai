export const Message = (userId, message, time) => {
    return {
        id : userId,
        message : message,
        time : time
    }
}
